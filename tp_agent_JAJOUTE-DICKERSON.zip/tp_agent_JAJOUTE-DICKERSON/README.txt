TP agent (version minimaliste, labo-safe)

- Coche: temporisation, planification, if/boucles, ordres à distance, kill switch,
  payload réseau (capture tshark), décorateurs, robustesse (retry/safe), tests pytest.

1) Lancer l'agent
  python agent.py

2) Envoyer des commandes
  python controller.py 127.0.0.1 5050 change-me PING
  python controller.py 127.0.0.1 5050 change-me STATUS
  python controller.py 127.0.0.1 5050 change-me CAPTURE '{"iface":"lo","seconds":5}'
  python controller.py 127.0.0.1 5050 change-me KILL

3) Tests + rapport
  pytest -q --junitxml=reports/pytest-report.xml

Notes:
- Pour CAPTURE, il faut tshark installé (Wireshark CLI) et les droits de capture.
- Adapte l'interface wifi (wlan0 / wlp2s0 / etc.) via WIFI_IFACE.
