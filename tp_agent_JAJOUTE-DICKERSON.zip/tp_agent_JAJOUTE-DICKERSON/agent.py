from __future__ import annotations
import json, os, time, sched, socket, threading, subprocess, logging
from dataclasses import dataclass
from typing import Any, Dict, Callable

# =====================
# Minimal "lab agent"
# - remote orders (TCP)
# - scheduling + sleep
# - if + loops
# - kill switch
# - payload network: short tshark capture on your own interfaces
# - decorators + robustness
# =====================

OUT_DIR = "out"
KILL_FLAG = "killswitch.flag"
os.makedirs(OUT_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(OUT_DIR, "agent.log"), encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

# ---- Decorators (required) ----
def safe(default=None):
    # Catch exceptions, log, return default.
    def deco(fn):
        def wrap(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception:
                logging.exception("Error in %s", fn.__name__)
                return default
        wrap.__name__ = getattr(fn, "__name__", "wrapped")
        return wrap
    return deco

def retry(times=3, delay_s=0.2):
    # Retry on exception.
    def deco(fn):
        def wrap(*args, **kwargs):
            last = None
            for i in range(times):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    last = e
                    logging.warning("retry %s (%d/%d): %s", fn.__name__, i+1, times, e)
                    time.sleep(delay_s)
            raise last
        wrap.__name__ = getattr(fn, "__name__", "wrapped")
        return wrap
    return deco

@dataclass
class Config:
    host: str = "0.0.0.0"
    port: int = 5050
    token: str = "change-me"   # set env AGENT_TOKEN to change
    loop_iface: str = "lo"
    wifi_iface: str = "wlan0"
    schedule_every_s: int = 60

class Agent:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.alive = True
        self.s = sched.scheduler(time.time, time.sleep)
        self.cmds: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
            "PING": self.ping,
            "STATUS": self.status,
            "CAPTURE": self.capture,  # safe "payload"
            "KILL": self.kill,
        }

    def killed(self) -> bool:
        return os.path.exists(KILL_FLAG)

    # ---- Commands ----
    @safe(default={"ok": False, "error": "ping_failed"})
    def ping(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": True, "pong": True, "ts": time.time()}

    @safe(default={"ok": False, "error": "status_failed"})
    def status(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "ok": True,
            "alive": self.alive,
            "kill_flag": self.killed(),
            "loop_iface": self.cfg.loop_iface,
            "wifi_iface": self.cfg.wifi_iface,
        }

    @safe(default={"ok": False, "error": "capture_failed"})
    def capture(self, args: Dict[str, Any]) -> Dict[str, Any]:
        # Network payload (lab-safe): short tshark capture on a chosen interface.
        iface = str(args.get("iface", self.cfg.loop_iface))
        seconds = int(args.get("seconds", 5))
        ts = int(time.time())

        pcap = os.path.join(OUT_DIR, f"cap_{iface}_{ts}.pcapng")
        report = os.path.join(OUT_DIR, f"report_{iface}_{ts}.txt")

        # Capture (needs tshark installed + permissions)
        cmd = ["tshark", "-i", iface, "-a", f"duration:{seconds}", "-w", pcap]
        logging.info("run: %s", " ".join(cmd))
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Tiny report (tcp conversations)
        rep = subprocess.run(
            ["tshark", "-r", pcap, "-q", "-z", "conv,tcp"],
            check=False,
            capture_output=True,
            text=True,
        )
        with open(report, "w", encoding="utf-8") as f:
            f.write(rep.stdout or "")
            if rep.stderr:
                f.write("\n[stderr]\n" + rep.stderr)

        return {"ok": True, "pcap": pcap, "report": report, "iface": iface, "seconds": seconds}

    @safe(default={"ok": False, "error": "kill_failed"})
    def kill(self, args: Dict[str, Any]) -> Dict[str, Any]:
        with open(KILL_FLAG, "w", encoding="utf-8") as f:
            f.write("killed\n")
        self.alive = False
        return {"ok": True, "killed": True}

    # ---- Scheduling ----
    def schedule_loop_capture(self) -> None:
        # Example scheduled task (planification).
        def job():
            if self.alive and not self.killed():  # if structure
                self.capture({"iface": self.cfg.loop_iface, "seconds": 3})
                self.s.enter(self.cfg.schedule_every_s, 1, job)
        self.s.enter(self.cfg.schedule_every_s, 1, job)

    def start_scheduler(self) -> None:
        threading.Thread(target=self.s.run, daemon=True).start()

    # ---- Remote control ----
    @retry(times=3, delay_s=0.1)
    def handle(self, conn: socket.socket) -> None:
        with conn:
            raw = conn.recv(65535).decode("utf-8", errors="replace").strip()
            req = json.loads(raw)
            if req.get("token") != self.cfg.token:
                conn.sendall(b'{"ok":false,"error":"unauthorized"}\n')
                return
            cmd = str(req.get("cmd", "")).upper()
            args = req.get("args") or {}
            if cmd not in self.cmds:
                conn.sendall(b'{"ok":false,"error":"unknown_cmd"}\n')
                return
            resp = self.cmds[cmd](args)
            conn.sendall((json.dumps(resp) + "\n").encode("utf-8"))

    def serve(self) -> None:
        logging.info("listen %s:%d", self.cfg.host, self.cfg.port)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((self.cfg.host, self.cfg.port))
            srv.listen(5)
            srv.settimeout(1.0)

            while self.alive:  # loop structure
                if self.killed():
                    logging.warning("kill flag found -> stopping")
                    self.alive = False
                    break
                try:
                    c, _ = srv.accept()
                except socket.timeout:
                    time.sleep(0.1)  # temporisation
                    continue
                threading.Thread(target=self.handle, args=(c,), daemon=True).start()

def main():
    cfg = Config(
        token=os.environ.get("AGENT_TOKEN", "change-me"),
        loop_iface=os.environ.get("LO_IFACE", "lo"),
        wifi_iface=os.environ.get("WIFI_IFACE", "wlan0"),
        schedule_every_s=int(os.environ.get("SCHED_EVERY", "60")),
    )
    a = Agent(cfg)
    a.schedule_loop_capture()
    a.start_scheduler()
    a.serve()

if __name__ == "__main__":
    main()
