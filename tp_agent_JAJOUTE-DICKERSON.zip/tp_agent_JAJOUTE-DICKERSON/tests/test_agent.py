# On importe les classes Agent et Config depuis le fichier agent.py
# Agent = le programme principal
# Config = la configuration de l’agent (port, token, etc.)
from agent import Agent, Config
# Définition d’un premier test unitaire
# Ce test vérifie que les commandes principales existent bien
def test_commands_exist():
    # Création d’une instance de l’agent avec une configuration minimale
    # On définit un token fictif "t" uniquement pour le test
    a = Agent(Config(token="t"))
    # Vérifie que la commande "PING" est bien enregistrée dans l’agent
    # Si ce n’est pas le cas, le test échoue
    assert "PING" in a.cmds
    # Vérifie que la commande "KILL" existe aussi
    # Cela garantit la présence du kill switch
    assert "KILL" in a.cmds
# Définition d’un second test unitaire
# Ce test vérifie que la commande STATUS fonctionne correctement
def test_status_ok():
    # Création d’une nouvelle instance de l’agent
    a = Agent(Config(token="t"))
    # Appel direct de la fonction status de l’agent
    # On passe un dictionnaire vide car STATUS n’a pas besoin d’arguments
    res = a.status({})
    # Vérifie que la réponse contient bien "ok": True
    # Cela signifie que la commande STATUS s’est exécutée correctement
    assert res["ok"] is True