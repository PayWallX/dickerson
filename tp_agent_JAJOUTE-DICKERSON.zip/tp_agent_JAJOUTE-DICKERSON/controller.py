import json, socket, sys

# Usage:
#   python controller.py <host> <port> <token> <CMD> [json_args]
#
# Examples:
#   python controller.py 127.0.0.1 5050 change-me PING
#   python controller.py 127.0.0.1 5050 change-me STATUS
#   python controller.py 127.0.0.1 5050 change-me CAPTURE '{"iface":"lo","seconds":5}'
#   python controller.py 127.0.0.1 5050 change-me KILL

# Fonction qui envoie une commande à distance à l’agent
def send(host, port, token, cmd, args):
    # Création du message à envoyer sous forme de dictionnaire Python
    # token : authentification simple
    # cmd   : commande à exécuter (PING, STATUS, CAPTURE, KILL)
    # args  : paramètres optionnels de la commande
    req = {"token": token, "cmd": cmd, "args": args}
    # Création d’une connexion TCP vers l’agent    # host = adresse IP de l’agent
    # port = port d’écoute de l’agent
    # timeout = évite de bloquer indéfiniment si l’agent ne répond pas
    with socket.create_connection((host, port), timeout=3) as s:
        # Conversion du dictionnaire en JSON
        # Ajout d’un retour à la ligne pour délimiter le message
        # Encodage en UTF-8 avant l’envoi sur le réseau
        s.sendall((json.dumps(req) + "\n").encode("utf-8"))
        # Réception de la réponse envoyée par l’agent
        # 65535 = taille maximale du buffer de réception
        # decode() permet de convertir les octets en texte lisible
        # errors="replace" évite une erreur si un caractère est invalide
        print(s.recv(65535).decode("utf-8", errors="replace"))
# Point d’entrée du programme
# Ce bloc est exécuté uniquement si le fichier est lancé directement
if __name__ == "__main__":
    # Récupération des arguments passés en ligne de commande
    # sys.argv[1] : adresse IP de l’agent
    # sys.argv[2] : port (converti en entier)
    # sys.argv[3] : token d’authentification
    # sys.argv[4] : commande à envoyer
    host, port, token, cmd = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    # Récupération des arguments optionnels de la commande
    # Si un 5e argument est présent, il est interprété comme du JSON
    # Sinon, on utilise un dictionnaire vide
    args = json.loads(sys.argv[5]) if len(sys.argv) > 5 else {}
    # Appel de la fonction send pour envoyer la commande à l’agent
    send(host, port, token, cmd, args)
